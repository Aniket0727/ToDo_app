from django.http import JsonResponse
from .models import Task
from django.http import HttpResponse



def get_tasks(request):
    tasks = Task.objects.all().values('id', 'title', 'description', 'status')
    return JsonResponse(list(tasks), safe=False)

def create_task(request):
    if request.method == 'POST':
        # Logic to create a new task (you can use Django forms or request body data)
        pass
def home(request):
    return HttpResponse("Welcome to the To-Do List API!")