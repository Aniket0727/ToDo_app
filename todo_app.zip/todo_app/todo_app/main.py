from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import sqlite3

# FastAPI app initialization
app = FastAPI()

# SQLite database connection
def get_db():
    conn = sqlite3.connect('tasks.db')
    return conn

# Create tasks table if not exists
def create_table():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS tasks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        description TEXT,
                        status TEXT DEFAULT 'pending')''')
    conn.commit()

create_table()

# Pydantic models for validation
class Task(BaseModel):
    title: str
    description: str
    status: str = 'pending'

class TaskInResponse(Task):
    id: int

# Endpoints
@app.post("/tasks", response_model=TaskInResponse)
def create_task(task: Task):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO tasks (title, description, status) 
                      VALUES (?, ?, ?)''', (task.title, task.description, task.status))
    conn.commit()
    task_id = cursor.lastrowid
    return {**task.dict(), "id": task_id}

@app.get("/tasks", response_model=List[TaskInResponse])
def get_tasks():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM tasks')
    tasks = cursor.fetchall()
    return [{"id": task[0], "title": task[1], "description": task[2], "status": task[3]} for task in tasks]

@app.get("/tasks/{task_id}", response_model=TaskInResponse)
def get_task(task_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
    task = cursor.fetchone()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"id": task[0], "title": task[1], "description": task[2], "status": task[3]}

@app.put("/tasks/{task_id}", response_model=TaskInResponse)
def update_task(task_id: int, task: Task):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''UPDATE tasks SET title = ?, description = ?, status = ? WHERE id = ?''',
                   (task.title, task.description, task.status, task_id))
    conn.commit()
    cursor.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
    updated_task = cursor.fetchone()
    if updated_task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"id": updated_task[0], "title": updated_task[1], "description": updated_task[2], "status": updated_task[3]}

@app.delete("/tasks/{task_id}")
def delete_task(task_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
    conn.commit()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Task deleted successfully"}
